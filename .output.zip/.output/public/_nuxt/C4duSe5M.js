import"./3iLDiuWg.js";const o=""+new URL("ict.Bojvc6n-.png",import.meta.url).href;export{o as _};
