import"./3iLDiuWg.js";const r=""+new URL("italparts.2qdfvmyn.png",import.meta.url).href;export{r as _};
