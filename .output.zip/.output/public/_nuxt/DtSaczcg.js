import"./3iLDiuWg.js";const r=""+new URL("profession.DSc87LxH.png",import.meta.url).href;export{r as _};
