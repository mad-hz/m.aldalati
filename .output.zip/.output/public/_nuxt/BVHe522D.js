import"./3iLDiuWg.js";const o=""+new URL("swot.KBVpCJmn.png",import.meta.url).href;export{o as _};
