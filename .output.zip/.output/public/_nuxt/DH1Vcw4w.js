import"./3iLDiuWg.js";const m=""+new URL("programming.DRvO2NAq.png",import.meta.url).href;export{m as _};
