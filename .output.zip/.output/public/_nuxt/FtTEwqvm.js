import"./3iLDiuWg.js";const o=""+new URL("study-choice.C2_Dz4Wv.png",import.meta.url).href;export{o as _};
