import"./3iLDiuWg.js";const r=""+new URL("feedback.CJhyeYET.png",import.meta.url).href;export{r as _};
